import type { AgentStatus } from "./types";

export type ServerConnection = {
  id: string;
  name: string;
  kind: "local" | "cloud";
  endpoint: string;
  status: string;
  current: boolean;
};

/**
 * Only the agent's own Postgres is reachable today. Multi-server support will
 * add entries here; the switcher is already shaped for it.
 */
export function serverList(status: AgentStatus | null): ServerConnection[] {
  return [
    {
      id: "local",
      name: "Local Postgres",
      kind: "local",
      endpoint: `${status?.host ?? "localhost"}:${status?.port ?? 5432}`,
      status: status?.active ?? "unknown",
      current: true,
    },
  ];
}
