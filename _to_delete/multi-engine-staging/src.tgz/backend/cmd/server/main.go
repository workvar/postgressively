package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/postggresively/backend/internal/agentclient"
	"github.com/postggresively/backend/internal/api"
	"github.com/postggresively/backend/internal/auth"
	"github.com/postggresively/backend/internal/config"
	"github.com/postggresively/backend/internal/passkey"
	"github.com/postggresively/backend/internal/pg"
)

func main() {
	// Helper: `server hashpw <password>` prints a bcrypt hash for the env file.
	if len(os.Args) == 3 && os.Args[1] == "hashpw" {
		h, err := auth.HashPassword(os.Args[2])
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println(h)
		return
	}

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("config: %v", err)
	}

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	// Opens the operator's database and the console's own database, creating
	// the latter (PG_META_DATABASE, default "postggresively") on first boot.
	dbs, err := pg.NewManager(ctx, cfg.DatabaseURL, cfg.MetaDatabase)
	if err != nil {
		log.Fatalf("database: %v", err)
	}
	defer dbs.Close()

	// Installs that predate the console database kept accounts in a schema
	// inside the operator's own database. Bring them across once.
	if copied, err := pg.MigrateLegacyUsers(ctx, dbs.Default(), dbs.Meta()); err != nil {
		log.Printf("legacy account migration: %v", err)
	} else if copied > 0 {
		log.Printf("migrated %d account(s) into database %q", copied, cfg.MetaDatabase)
	}

	// Passkeys are optional: a bad relying-party config degrades to
	// password-only rather than stopping the console from booting.
	passkeys, err := passkey.New(dbs.Meta(), cfg.RPID, cfg.RPDisplayName, cfg.RPOrigins)
	if err != nil {
		log.Printf("passkeys disabled: %v", err)
		passkeys = nil
	}

	srv := &http.Server{
		Addr:              cfg.Addr,
		Handler:           api.NewServer(cfg, dbs, agentclient.New(cfg.AgentURL, cfg.AgentToken), passkeys).Handler(),
		ReadHeaderTimeout: 10 * time.Second,
	}

	go func() {
		log.Printf("backend listening on %s (read-only=%v)", cfg.Addr, cfg.ReadOnly)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("listen: %v", err)
		}
	}()

	<-ctx.Done()
	shutdownCtx, stop := context.WithTimeout(context.Background(), 10*time.Second)
	defer stop()
	_ = srv.Shutdown(shutdownCtx)
	log.Println("backend stopped")
}
