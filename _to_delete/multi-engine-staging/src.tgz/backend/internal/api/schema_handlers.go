package api

import (
	"fmt"
	"net/http"
	"strconv"

	"github.com/postggresively/backend/internal/pg"
)

func (s *Server) handleDatabases(w http.ResponseWriter, r *http.Request) {
	dbs, err := s.store.Databases(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	def := s.dbs.DefaultName()
	for i := range dbs {
		dbs[i].IsDefault = dbs[i].Name == def
	}
	writeJSON(w, http.StatusOK, dbs)
}

// storeFor resolves the ?db= query parameter to a pooled connection,
// falling back to the configured default database.
func (s *Server) storeFor(r *http.Request) (*pg.Store, error) {
	return s.dbs.Store(r.Context(), r.URL.Query().Get("db"))
}

func (s *Server) handleTables(w http.ResponseWriter, r *http.Request) {
	store, err := s.storeFor(r)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	tables, err := store.Tables(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, tables)
}

func (s *Server) handleTableDetail(w http.ResponseWriter, r *http.Request) {
	schema, table := r.PathValue("schema"), r.PathValue("table")
	store, err := s.storeFor(r)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	cols, err := store.Columns(r.Context(), schema, table)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	idx, err := store.Indexes(r.Context(), schema, table)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"schema":  schema,
		"table":   table,
		"columns": cols,
		"indexes": idx,
	})
}

// handleTableRows previews rows using a quoted identifier to avoid injection.
func (s *Server) handleTableRows(w http.ResponseWriter, r *http.Request) {
	schema, table := r.PathValue("schema"), r.PathValue("table")
	store, err := s.storeFor(r)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	limit := s.cfg.MaxRows
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= s.cfg.MaxRows {
			limit = n
		}
	}
	sql := fmt.Sprintf("SELECT * FROM %s.%s LIMIT %d", quoteIdent(schema), quoteIdent(table), limit)
	res, err := store.Run(r.Context(), sql, s.queryOptions(true))
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, res)
}

func (s *Server) queryOptions(readOnly bool) pg.QueryOptions {
	return pg.QueryOptions{
		MaxRows:  s.cfg.MaxRows,
		Timeout:  s.cfg.QueryTimeout,
		ReadOnly: readOnly || s.cfg.ReadOnly,
	}
}

func quoteIdent(s string) string {
	out := make([]rune, 0, len(s)+2)
	out = append(out, '"')
	for _, r := range s {
		if r == '"' {
			out = append(out, '"')
		}
		out = append(out, r)
	}
	return string(append(out, '"'))
}
