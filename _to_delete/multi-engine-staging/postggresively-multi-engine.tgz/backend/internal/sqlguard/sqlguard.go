package sqlguard

import (
	"regexp"
	"strings"
)

var writeVerbs = regexp.MustCompile(`(?i)^\s*(insert|update|delete|drop|truncate|alter|create|grant|revoke|copy|vacuum|reindex|refresh)\b`)

// IsReadOnly reports whether every statement in sql is a read.
func IsReadOnly(sql string) bool {
	for _, stmt := range SplitStatements(sql) {
		if writeVerbs.MatchString(stmt) {
			return false
		}
	}
	return true
}

// SplitStatements does a naive split on semicolons outside of quotes.
func SplitStatements(sql string) []string {
	var out []string
	var buf strings.Builder
	var quote rune
	for _, r := range sql {
		switch {
		case quote != 0:
			if r == quote {
				quote = 0
			}
			buf.WriteRune(r)
		case r == '\'' || r == '"':
			quote = r
			buf.WriteRune(r)
		case r == ';':
			if s := strings.TrimSpace(buf.String()); s != "" {
				out = append(out, s)
			}
			buf.Reset()
		default:
			buf.WriteRune(r)
		}
	}
	if s := strings.TrimSpace(buf.String()); s != "" {
		out = append(out, s)
	}
	return out
}
