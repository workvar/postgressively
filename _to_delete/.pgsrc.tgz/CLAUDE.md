# Project conventions

Standing rules for this repo. Apply them to every change, including future features.

## UI

### Dropdowns must be searchable

Never use a native `<select>` element. All single-choice dropdowns use
`web/components/ui/Combobox.tsx`, which renders a text input with type-ahead
filtering, keyboard navigation, and a styled option list.

```tsx
import Combobox from "@/components/ui/Combobox";

<Combobox
  aria-label="Database"
  options={items.map((d) => ({ value: d.name, label: d.name, hint: bytes(d.size) }))}
  value={value}
  onChange={setValue}
  placeholder="Search databases…"
  emptyText="No databases match"
/>
```

- `hint` is secondary text shown under the label; it is also matched by the search.
- Wrap in `<Field label="…">` inside forms.
- The native `Select` export was removed from `components/ui/Field.tsx` on purpose.
  If a new picker is needed, extend `Combobox` rather than reintroducing `<select>`.

### Other UI rules

- Reuse the primitives in `web/components/ui/` (`Button`, `Field`, `Panel`, `Tabs`,
  `Table`, `Badge`) instead of hand-rolling styles.
- Colors, spacing, and easing come from Tailwind tokens defined in
  `web/tailwind.config.ts` (`fg`, `surface`, `line`, `accent`, `ease-apple`, …).
  Do not hardcode hex values.

## Code layout

- Keep files small and single-purpose. Split page logic into feature folders under
  `web/components/<feature>/` and data fetching into `web/lib/`.
- Backend handlers stay thin; SQL and Postgres logic lives in `backend/internal/pg/`.

## Multi-database access

Table and schema endpoints are scoped by a `?db=<name>` query parameter, resolved by
`pg.Manager` (`backend/internal/pg/manager.go`), which caches one connection pool per
database. New per-database endpoints should use `Server.storeFor(r)` rather than the
default `Server.store`.
