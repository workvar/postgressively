package api

import (
	"context"
	"net/http"
)

type ctxKey int

const subjectKey ctxKey = iota

// withSubject stores the authenticated username on the request context.
func withSubject(r *http.Request, username string) *http.Request {
	return r.WithContext(context.WithValue(r.Context(), subjectKey, username))
}

// subject returns the authenticated username, or "" for unauthenticated routes.
func subject(r *http.Request) string {
	name, _ := r.Context().Value(subjectKey).(string)
	return name
}
