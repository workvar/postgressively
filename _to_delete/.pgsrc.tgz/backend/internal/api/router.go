package api

import (
	"net/http"

	"github.com/postggresively/backend/internal/agentclient"
	"github.com/postggresively/backend/internal/config"
	"github.com/postggresively/backend/internal/pg"
)

// Server wires config, database access and the agent client into HTTP handlers.
type Server struct {
	cfg   *config.Config
	store *pg.Store
	dbs   *pg.Manager
	agent *agentclient.Client
}

func NewServer(cfg *config.Config, dbs *pg.Manager, agent *agentclient.Client) *Server {
	return &Server{cfg: cfg, store: dbs.Default(), dbs: dbs, agent: agent}
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	})
	// Public: the client needs these before an account exists.
	mux.HandleFunc("GET /api/setup/status", s.handleSetupStatus)
	mux.HandleFunc("POST /api/setup", s.handleSetup)

	mux.HandleFunc("POST /api/login", s.handleLogin)
	mux.HandleFunc("GET /api/me", s.requireAuth(s.handleMe))
	mux.HandleFunc("POST /api/account/password", s.requireAuth(s.handlePasswordChange))

	mux.HandleFunc("GET /api/databases", s.requireAuth(s.handleDatabases))
	mux.HandleFunc("GET /api/databases/details", s.requireAuth(s.handleDatabaseDetails))
	mux.HandleFunc("POST /api/databases", s.requireAuth(s.handleDatabaseCreate))
	mux.HandleFunc("DELETE /api/databases/{name}", s.requireAuth(s.handleDatabaseDrop))
	mux.HandleFunc("GET /api/databases/{name}/extensions", s.requireAuth(s.handleDatabaseExtensions))

	mux.HandleFunc("GET /api/tables", s.requireAuth(s.handleTables))
	mux.HandleFunc("GET /api/tables/{schema}/{table}", s.requireAuth(s.handleTableDetail))
	mux.HandleFunc("GET /api/tables/{schema}/{table}/rows", s.requireAuth(s.handleTableRows))

	mux.HandleFunc("POST /api/query", s.requireAuth(s.handleQuery))
	mux.HandleFunc("GET /api/activity", s.requireAuth(s.handleActivity))
	mux.HandleFunc("POST /api/activity/{pid}/terminate", s.requireAuth(s.handleTerminate))

	mux.HandleFunc("GET /api/agent/status", s.requireAuth(s.handleAgentStatus))
	mux.HandleFunc("GET /api/agent/stats", s.requireAuth(s.handleAgentStats))
	mux.HandleFunc("GET /api/agent/discover", s.requireAuth(s.handleAgentDiscover))
	mux.HandleFunc("POST /api/agent/service/{action}", s.requireAuth(s.handleAgentService))
	mux.HandleFunc("GET /api/agent/backups", s.requireAuth(s.handleBackupsList))
	mux.HandleFunc("POST /api/agent/backups", s.requireAuth(s.handleBackupCreate))
	mux.HandleFunc("GET /api/agent/logs", s.requireAuth(s.handleAgentLogs))

	return s.withCORS(withLogging(mux))
}
