package api

import (
	"errors"
	"net/http"

	"github.com/postggresively/backend/internal/auth"
	"github.com/postggresively/backend/internal/pg"
)

type loginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// issueSession signs a JWT for username and writes it as the response body.
func (s *Server) issueSession(w http.ResponseWriter, username string, status int) {
	token, exp, err := auth.Issue(s.cfg.JWTSecret, username)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, status, map[string]any{
		"token":     token,
		"expiresAt": exp,
		"username":  username,
	})
}

func (s *Server) handleLogin(w http.ResponseWriter, r *http.Request) {
	var req loginRequest
	if err := decode(r, &req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}

	// A fresh install has no accounts yet; steer the client to the wizard.
	n, err := s.store.CountUsers(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	if n == 0 {
		writeErr(w, http.StatusConflict, "setup required")
		return
	}

	user, err := s.store.FindUser(r.Context(), req.Username)
	if errors.Is(err, pg.ErrNoUser) {
		writeErr(w, http.StatusUnauthorized, "invalid credentials")
		return
	}
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	if !auth.CheckPassword(user.PasswordHash, req.Password) {
		writeErr(w, http.StatusUnauthorized, "invalid credentials")
		return
	}

	s.issueSession(w, user.Username, http.StatusOK)
}

func (s *Server) handleMe(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"username": subject(r),
		"readOnly": s.cfg.ReadOnly,
		"maxRows":  s.cfg.MaxRows,
	})
}
