package api

import (
	"net/http"

	"github.com/postggresively/backend/internal/pg"
)

// GET /api/databases/details
func (s *Server) handleDatabaseDetails(w http.ResponseWriter, r *http.Request) {
	details, err := s.store.DatabaseDetails(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, details)
}

// POST /api/databases
func (s *Server) handleDatabaseCreate(w http.ResponseWriter, r *http.Request) {
	var spec pg.CreateDatabaseSpec
	if err := decode(r, &spec); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid request body")
		return
	}

	if err := spec.Validate(); err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}

	res, err := s.store.CreateDatabase(r.Context(), spec)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusCreated, res)
}

// DELETE /api/databases/{name}
func (s *Server) handleDatabaseDrop(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	if err := s.store.DropDatabase(r.Context(), name); err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"dropped": name})
}

// GET /api/databases/{name}/extensions
func (s *Server) handleDatabaseExtensions(w http.ResponseWriter, r *http.Request) {
	exts, err := s.store.Extensions(r.Context(), r.PathValue("name"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, exts)
}
