package api

import (
	"net/http"
	"strconv"

	"github.com/postggresively/backend/internal/pg"
)

type queryRequest struct {
	SQL string `json:"sql"`
}

func (s *Server) handleQuery(w http.ResponseWriter, r *http.Request) {
	var req queryRequest
	if err := decode(r, &req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	stmts := pg.SplitStatements(req.SQL)
	if len(stmts) == 0 {
		writeErr(w, http.StatusBadRequest, "empty statement")
		return
	}
	results := make([]*pg.QueryResult, 0, len(stmts))
	for _, stmt := range stmts {
		res, err := s.store.Run(r.Context(), stmt, s.queryOptions(false))
		if err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{
				"error":     err.Error(),
				"statement": stmt,
				"results":   results,
			})
			return
		}
		results = append(results, res)
	}
	writeJSON(w, http.StatusOK, map[string]any{"results": results})
}

func (s *Server) handleActivity(w http.ResponseWriter, r *http.Request) {
	acts, err := s.store.Activity(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, acts)
}

func (s *Server) handleTerminate(w http.ResponseWriter, r *http.Request) {
	if s.cfg.ReadOnly {
		writeErr(w, http.StatusForbidden, "server is in read-only mode")
		return
	}
	pid, err := strconv.Atoi(r.PathValue("pid"))
	if err != nil {
		writeErr(w, http.StatusBadRequest, "invalid pid")
		return
	}
	if err := s.store.Terminate(r.Context(), pid); err != nil {
		writeErr(w, http.StatusInternalServerError, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"terminated": pid})
}
