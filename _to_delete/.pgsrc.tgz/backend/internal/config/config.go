package config

import (
	"errors"
	"os"
	"strconv"
	"time"
)

// Config holds all runtime settings, sourced from environment variables.
type Config struct {
	Addr         string
	DatabaseURL  string
	JWTSecret    string
	AgentURL     string
	AgentToken   string
	CORSOrigin   string
	ReadOnly     bool
	MaxRows      int
	QueryTimeout time.Duration
}

func Load() (*Config, error) {
	c := &Config{
		Addr:         env("PG_ADDR", ":8080"),
		DatabaseURL:  os.Getenv("PG_DATABASE_URL"),
		JWTSecret:    os.Getenv("PG_JWT_SECRET"),
		AgentURL:     env("PG_AGENT_URL", "http://127.0.0.1:8081"),
		AgentToken:   os.Getenv("PG_AGENT_TOKEN"),
		CORSOrigin:   env("PG_CORS_ORIGIN", "http://localhost:3000"),
		ReadOnly:     env("PG_READ_ONLY", "false") == "true",
		MaxRows:      envInt("PG_MAX_ROWS", 500),
		QueryTimeout: time.Duration(envInt("PG_QUERY_TIMEOUT_SECONDS", 30)) * time.Second,
	}
	if c.DatabaseURL == "" {
		return nil, errors.New("PG_DATABASE_URL is required")
	}
	if c.JWTSecret == "" {
		return nil, errors.New("PG_JWT_SECRET is required")
	}
	return c, nil
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func envInt(k string, def int) int {
	if v := os.Getenv(k); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return def
}
