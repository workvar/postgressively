package pg

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
)

// ErrNoUser is returned when a console account does not exist.
var ErrNoUser = errors.New("user not found")

// ErrAlreadySetup is returned when first-run setup runs a second time.
var ErrAlreadySetup = errors.New("console is already set up")

// schemaDDL creates the private namespace this app uses for its own state.
// It is intentionally separate from the user's data so nothing lands in public.
const schemaDDL = `
CREATE SCHEMA IF NOT EXISTS postggresively;

CREATE TABLE IF NOT EXISTS postggresively.users (
	id            bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
	username      text        NOT NULL UNIQUE,
	password_hash text        NOT NULL,
	created_at    timestamptz NOT NULL DEFAULT now(),
	updated_at    timestamptz NOT NULL DEFAULT now()
);`

// User is a console account. Credentials live in the managed database, not in
// the environment, so they can be changed without restarting the server.
type User struct {
	Username     string
	PasswordHash string
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

// EnsureUserStore creates the app schema and users table if they are missing.
func (s *Store) EnsureUserStore(ctx context.Context) error {
	_, err := s.Pool.Exec(ctx, schemaDDL)
	return err
}

// CountUsers reports how many console accounts exist. Zero means setup is due.
func (s *Store) CountUsers(ctx context.Context) (int, error) {
	var n int
	err := s.Pool.QueryRow(ctx, `SELECT count(*) FROM postggresively.users`).Scan(&n)
	return n, err
}

// FindUser looks up one account by name, returning ErrNoUser when absent.
func (s *Store) FindUser(ctx context.Context, username string) (*User, error) {
	const q = `
		SELECT username, password_hash, created_at, updated_at
		FROM postggresively.users
		WHERE username = $1`

	var u User
	err := s.Pool.QueryRow(ctx, q, username).
		Scan(&u.Username, &u.PasswordHash, &u.CreatedAt, &u.UpdatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNoUser
	}
	if err != nil {
		return nil, err
	}
	return &u, nil
}

// CreateFirstUser inserts the initial account, but only while none exists.
// The guard is in SQL so two concurrent setup requests cannot both win.
func (s *Store) CreateFirstUser(ctx context.Context, username, hash string) error {
	const q = `
		INSERT INTO postggresively.users (username, password_hash)
		SELECT $1, $2
		WHERE NOT EXISTS (SELECT 1 FROM postggresively.users)`

	tag, err := s.Pool.Exec(ctx, q, username, hash)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrAlreadySetup
	}
	return nil
}

// SetPassword replaces the stored hash for an existing account.
func (s *Store) SetPassword(ctx context.Context, username, hash string) error {
	const q = `
		UPDATE postggresively.users
		SET password_hash = $2, updated_at = now()
		WHERE username = $1`

	tag, err := s.Pool.Exec(ctx, q, username, hash)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNoUser
	}
	return nil
}
