package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/postggresively/backend/internal/agentclient"
	"github.com/postggresively/backend/internal/api"
	"github.com/postggresively/backend/internal/auth"
	"github.com/postggresively/backend/internal/config"
	"github.com/postggresively/backend/internal/pg"
)

func main() {
	// Helper: `server hashpw <password>` prints a bcrypt hash for the env file.
	if len(os.Args) == 3 && os.Args[1] == "hashpw" {
		h, err := auth.HashPassword(os.Args[2])
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println(h)
		return
	}

	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("config: %v", err)
	}

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	dbs, err := pg.NewManager(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("database: %v", err)
	}
	defer dbs.Close()

	// Console accounts live in the managed database; make sure the table exists
	// before the first request so /api/setup/status can answer.
	if err := dbs.Default().EnsureUserStore(ctx); err != nil {
		log.Fatalf("user store: %v", err)
	}

	srv := &http.Server{
		Addr:              cfg.Addr,
		Handler:           api.NewServer(cfg, dbs, agentclient.New(cfg.AgentURL, cfg.AgentToken)).Handler(),
		ReadHeaderTimeout: 10 * time.Second,
	}

	go func() {
		log.Printf("backend listening on %s (read-only=%v)", cfg.Addr, cfg.ReadOnly)
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("listen: %v", err)
		}
	}()

	<-ctx.Done()
	shutdownCtx, stop := context.WithTimeout(context.Background(), 10*time.Second)
	defer stop()
	_ = srv.Shutdown(shutdownCtx)
	log.Println("backend stopped")
}
