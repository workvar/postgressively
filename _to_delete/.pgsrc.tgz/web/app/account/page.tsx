"use client";

import { useEffect, useState } from "react";
import Shell from "@/components/Shell";
import PasswordForm from "@/components/account/PasswordForm";
import PageHeader from "@/components/layout/PageHeader";
import Panel from "@/components/ui/Panel";
import { api } from "@/lib/api";

type Me = { username: string; readOnly: boolean; maxRows: number };

export default function AccountPage() {
  const [me, setMe] = useState<Me | null>(null);

  useEffect(() => {
    api.get<Me>("/api/me").then(setMe).catch(() => setMe(null));
  }, []);

  return (
    <Shell>
      <PageHeader
        title="Account"
        description={
          me ? `Signed in as ${me.username}.` : "Your console sign-in details."
        }
      />
      <Panel
        title="Change password"
        description="Stored as a bcrypt hash in the postggresively schema of the connected database."
      >
        <PasswordForm />
      </Panel>
    </Shell>
  );
}
