"use client";

import { useState } from "react";
import Shell from "@/components/Shell";
import DataTable from "@/components/DataTable";
import PageHeader from "@/components/layout/PageHeader";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Field";
import { EmptyState, ErrorNote } from "@/components/ui/Panel";
import { api } from "@/lib/api";
import type { QueryResult } from "@/lib/types";

const snippets: [string, string][] = [
  ["Server version", "SELECT version();"],
  ["Database sizes", "SELECT datname, pg_size_pretty(pg_database_size(datname)) AS size\nFROM pg_database\nORDER BY pg_database_size(datname) DESC;"],
  ["Biggest tables", "SELECT relname, pg_size_pretty(pg_total_relation_size(relid)) AS size\nFROM pg_catalog.pg_statio_user_tables\nORDER BY pg_total_relation_size(relid) DESC\nLIMIT 20;"],
  ["Long-running queries", "SELECT pid, now() - query_start AS runtime, state, query\nFROM pg_stat_activity\nWHERE state <> 'idle'\nORDER BY runtime DESC;"],
];

export default function QueryPage() {
  const [sql, setSql] = useState("SELECT now(), version();");
  const [results, setResults] = useState<QueryResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    setError(null);
    try {
      const res = await api.post<{ results: QueryResult[] }>("/api/query", { sql });
      setResults(res.results);
    } catch (e) {
      setError(e instanceof Error ? e.message : "query failed");
      setResults([]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Shell>
      <PageHeader
        title="SQL console"
        description="Run statements against the connected database."
        action={
          <>
            <span className="hidden text-caption text-fg-subtle sm:inline">⌘ / Ctrl + Enter</span>
            <Button size="md" onClick={run} disabled={busy}>
              {busy ? "Running…" : "Run query"}
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[minmax(0,1fr)_260px]">
        <div className="min-w-0">
          <div className="overflow-hidden rounded-xl border border-line bg-surface shadow-card">
            <div className="flex items-center justify-between border-b border-line bg-surface-2 px-3 py-1.5">
              <span className="text-caption font-medium text-fg-muted">Statement</span>
              <button
                onClick={() => setSql("")}
                className="text-caption text-fg-subtle transition-colors hover:text-fg"
              >
                Clear
              </button>
            </div>
            <Textarea
              value={sql}
              onChange={(e) => setSql(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") run();
              }}
              rows={10}
              spellCheck={false}
              aria-label="SQL statement"
              className="!rounded-none !border-0 !bg-transparent font-mono !text-caption"
            />
          </div>

          {error && (
            <div className="mt-4">
              <ErrorNote>{error}</ErrorNote>
            </div>
          )}

          <div className="mt-5 space-y-6">
            {results.map((r, i) => (
              <div key={i} className="animate-fadeUp">
                <div className="mb-2 flex flex-wrap items-center gap-1.5">
                  <Badge tone="accent">{r.command}</Badge>
                  <Badge>{r.rowCount} rows</Badge>
                  <Badge>{r.durationMs.toFixed(1)} ms</Badge>
                  {r.truncated && <Badge tone="warning">truncated</Badge>}
                </div>
                <DataTable columns={r.columns} rows={r.rows} />
              </div>
            ))}
            {results.length === 0 && !error && (
              <div className="rounded-xl border border-dashed border-line-strong bg-surface/60">
                <EmptyState title="No results yet">
                  Run a statement to see rows, timing, and the command tag here.
                </EmptyState>
              </div>
            )}
          </div>
        </div>

        <aside className="h-fit rounded-xl border border-line bg-surface p-3 shadow-card">
          <h2 className="mb-2 text-caption font-semibold uppercase tracking-[0.06em] text-fg-subtle">
            Snippets
          </h2>
          <ul className="space-y-1">
            {snippets.map(([label, body]) => (
              <li key={label}>
                <button
                  onClick={() => setSql(body)}
                  className="w-full rounded-lg px-2.5 py-2 text-left text-small text-fg-muted transition-colors duration-150 ease-apple hover:bg-surface-2 hover:text-fg"
                >
                  {label}
                </button>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </Shell>
  );
}
