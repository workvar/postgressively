"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import Logo from "@/components/brand/Logo";
import NavIcon from "./NavIcon";
import ServerSwitcher from "./ServerSwitcher";
import { navGroups } from "./nav";

export default function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const pathname = usePathname();

  return (
    <aside
      className={`${
        collapsed ? "w-[64px]" : "w-[228px]"
      } sticky top-0 hidden h-screen shrink-0 flex-col border-r border-line bg-surface transition-[width] duration-250 ease-apple md:flex`}
    >
      <div className="flex h-14 items-center border-b border-line px-4">
        <Link href="/" aria-label="Postggresively home">
          <Logo compact={collapsed} />
        </Link>
      </div>

      <ServerSwitcher collapsed={collapsed} />

      <div className="px-3 py-3">
        <Link
          href="/databases/new"
          title={collapsed ? "New database" : undefined}
          className="flex h-9 items-center justify-center gap-1.5 rounded-lg bg-brand px-3 text-small font-medium text-white transition-colors duration-150 ease-apple hover:bg-brand-hover"
        >
          <NavIcon name="plus" />
          {!collapsed && "New database"}
        </Link>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 pb-3">
        {navGroups.map((group, gi) => (
          <div key={group.title ?? gi} className="mb-4">
            {group.title && !collapsed && (
              <p className="mb-1 px-2.5 text-micro font-semibold uppercase tracking-[0.08em] text-fg-subtle">
                {group.title}
              </p>
            )}
            <ul className="space-y-px">
              {group.items.map((item) => {
                const active = pathname === item.href;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      title={collapsed ? item.label : undefined}
                      className={`flex h-8 items-center gap-2.5 rounded-lg px-2.5 text-small transition-colors duration-150 ease-apple ${
                        active
                          ? "bg-accent-soft font-semibold text-accent"
                          : "text-fg-muted hover:bg-surface-2 hover:text-fg"
                      }`}
                    >
                      <NavIcon name={item.icon} />
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <button
        onClick={onToggle}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        className="flex h-10 items-center justify-center border-t border-line text-fg-subtle transition-colors duration-150 ease-apple hover:bg-surface-2 hover:text-fg"
      >
        <svg viewBox="0 0 20 20" fill="none" className="h-4 w-4">
          <path
            d={collapsed ? "M8 5l5 5-5 5" : "M12 5l-5 5 5 5"}
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>
    </aside>
  );
}
