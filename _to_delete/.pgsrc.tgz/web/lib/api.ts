import { clearToken, getToken } from "./auth";

const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8080";

export class ApiError extends Error {}

async function request<T>(
  path: string,
  init: RequestInit = {},
  redirectOn401 = true,
): Promise<T> {
  const token = getToken();
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });

  if (res.status === 401 && redirectOn401) {
    clearToken();
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new ApiError("unauthorized");
  }

  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(body?.error ?? `request failed (${res.status})`);
  return body as T;
}

/**
 * Same transport as `api`, but a 401 is surfaced to the caller instead of
 * bouncing to /login. Use it where the form itself explains the failure,
 * such as a wrong current password.
 */
export const apiSafe = {
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }, false),
};

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  del: <T>(path: string) => request<T>(path, { method: "DELETE" }),
};

export async function login(username: string, password: string) {
  const res = await fetch(`${BASE}/api/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(body?.error ?? "login failed");
  return body as { token: string; username: string; expiresAt: string };
}
