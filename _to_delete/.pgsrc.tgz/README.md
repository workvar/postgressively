# Postggresively

A web console for the Postgres instance running on your server. Three pieces:

| Component | Stack | Role |
| --- | --- | --- |
| `agent/` | Go, stdlib only | Runs on the DB host. Controls the systemd unit, reads host stats and logs, runs `pg_dump`. Binds to localhost. |
| `backend/` | Go, pgx + JWT | Public API. Auth, schema introspection, query execution, proxies privileged calls to the agent. |
| `web/` | Next.js 14 (App Router) + Tailwind | UI: overview, schema browser, SQL console, server control. |

## Why the split

The agent is the only component that touches the operating system. It holds no
database credentials of its own beyond the local socket user and it never
accepts requests from outside the host. The backend is the only component that
speaks SQL, and it is the only thing exposed to the browser. That means you can
lock the agent down (`AGENT_ADDR=127.0.0.1:8081`) and still run the backend and
UI on a different port, behind TLS.

## Quick start (local dev)

```bash
# 1. agent
cp agent/.env.example agent/.env
make agent

# 2. backend (new shell)
cp backend/.env.example backend/.env
make backend

# 3. web (new shell)
cd web && npm install
cp .env.local.example .env.local
npm run dev
```

Open http://localhost:3000. On a fresh database the app redirects to `/setup`,
where you pick the console username and password. They are stored as a bcrypt
hash in the `postggresively` schema of the database `PG_DATABASE_URL` points at,
so no credentials live in the environment. Change the password later from the
account page (avatar in the top right).

Locked out? Clear the account and the wizard runs again on next load:

```sql
DELETE FROM postggresively.users;
```

## API surface

```
GET    /api/setup/status                       -> { needsSetup }   (public)
POST   /api/setup                              -> { token }        (public, first run only)
POST   /api/login                              -> { token }
GET    /api/me
POST   /api/account/password                   -> { token }
GET    /api/databases
GET    /api/tables
GET    /api/tables/{schema}/{table}            -> columns + indexes
GET    /api/tables/{schema}/{table}/rows       -> preview rows
POST   /api/query                              -> { sql } multi-statement
GET    /api/activity
POST   /api/activity/{pid}/terminate
GET    /api/agent/status | /stats | /logs
POST   /api/agent/service/{start|stop|restart|reload}
GET    POST /api/agent/backups
```

## Safety rails in v1

- `PG_READ_ONLY=true` rejects any statement starting with a write verb, blocks
  `pg_terminate_backend`, and blocks service control.
- Every query runs with `statement_timeout` set from `PG_QUERY_TIMEOUT_SECONDS`
  and results are capped at `PG_MAX_ROWS` (the response flags `truncated`).
- Table and schema names from URLs are quoted as identifiers before
  interpolation; row previews never take raw SQL from the client.
- The agent validates database names against `^[A-Za-z0-9_-]{1,63}$` before
  passing them to `pg_dump`, and only accepts four fixed systemd actions.
- Agent auth is a constant-time comparison against a 32+ character token.

## Production deploy

```bash
make build
sudo install bin/postggresively-agent bin/postggresively-backend /usr/local/bin/
sudo mkdir -p /etc/postggresively
# copy the two .env files to /etc/postggresively/{agent,backend}.env, chmod 600
sudo cp deploy/*.service /etc/systemd/system/
sudo systemctl enable --now postggresively-agent postggresively-backend
```

The agent needs privileges to run `systemctl` on the Postgres unit and to write
to `AGENT_BACKUP_DIR`. Running it as root is the simple path; a tighter setup is
a dedicated user plus a polkit rule or a narrow sudoers entry.

Put the backend behind a reverse proxy with TLS. Serve the Next.js app from the
same origin, or set `PG_CORS_ORIGIN` to the UI's exact origin.

## Known gaps for v2

- Single admin user from env. Real user table, roles, and audit log next.
- One target database per backend process; add a connection registry so you can
  switch databases from the UI.
- No `pg_restore` path yet, and no backup retention or scheduling.
- No streaming for large result sets; everything is materialized in memory.
- The read-only guard is a regex over statements, not a Postgres-level
  `default_transaction_read_only` session. Use a read-only DB role for hard
  guarantees.
